def preprocessor(data):
    preprocessed_data=preprocess.transform(data)
    return preprocessed_data
